clustering.py is used to obtain the coordinates of point obstacles that are clustered together which can be used as input to modified circle rolling and aerial glide simulation both. 
If you type 1 for image , the photo is downloaded in the working directory for your visualization. 
You have to type 'cr' fo rcircle rolling and 'ag' for aerial glide becasue the content of input files of both are different. 
